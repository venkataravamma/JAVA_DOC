package com.springdatajpa.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
